# Northparavur.info
Website created for a small but historical town, North Paravur. North paravur is located in Kerala, A state in south India.
