var updates = [
    {
        id="1",
        category: "news",
        date: "27/12/2020",
        content: "This is a test news"
    },
    {
        id="2",
        category: "events",
        date: "27/12/2020",
        content: "This is a text event"
    },
    {
        id="1",
        category: "information",
        date: "27/12/2020",
        content: "This is a text information"
    },
];